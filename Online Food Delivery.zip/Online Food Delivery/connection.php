<?php
$conn=mysqli_connect("localhost", "root", "", "admin") or mysqli_connect_error();
?>