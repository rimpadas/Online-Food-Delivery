<html>
<head>
</head>
<script>
setTimeout (function() {
    window.location.href = 'http://localhost/projectwork/foodlist.php';
}, 5000);
</script>
<body>
<center>
<img src="images/giphy.gif" style="width: 35%; height:60%;">
</center>
<h1 align="center">Thank you</h1>
<h2 align="center" style="color:green;" >Order Confirmed</h2>
<h3 align="center"    &nbsp>It will be deliver soon....</h3>
</body>
</html>